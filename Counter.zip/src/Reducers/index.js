import { combineReducers } from "redux";

import counter from "./counterReducer";

export default combineReducers({
  counter,
});
